void main(void)
{
  unsigned int i, j;
  for (i=0; i<0x2233; i++)
    j= i;
}
