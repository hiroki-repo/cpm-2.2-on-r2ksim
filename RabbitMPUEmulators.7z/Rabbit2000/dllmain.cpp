﻿// dllmain.cpp : DLL アプリケーションのエントリ ポイントを定義します。
#include "pch.h"
#include "r2kcl.h"
#include "globals.h"
#include "simcl.h"
#include "ez80cl.h"

cl_app* clapp4emu;
cl_sim* clsim4emu;

extern "C" __declspec(dllexport) cl_r2k* getr2k() { clapp4emu = new cl_app(); clsim4emu=new cl_sim(clapp4emu); return new cl_r2k(cpus_z80, clsim4emu); }
extern "C" __declspec(dllexport) cl_r3ka* getr3ka() { clapp4emu = new cl_app(); clsim4emu=new cl_sim(clapp4emu); return new cl_r3ka(cpus_z80, clsim4emu); }
extern "C" __declspec(dllexport) cl_z80* getz80() { clapp4emu = new cl_app(); clsim4emu=new cl_sim(clapp4emu); return new cl_z80(cpus_z80, clsim4emu); }
extern "C" __declspec(dllexport) cl_ez80 * getez80() { clapp4emu = new cl_app(); clsim4emu = new cl_sim(clapp4emu); return new cl_ez80(cpus_z80, clsim4emu); }
extern "C" __declspec(dllexport) cl_app* getcl_app() { return clapp4emu; }
extern "C" __declspec(dllexport) cl_sim* getcl_sim() { return clsim4emu; }
extern "C" __declspec(dllexport) cl_uc* getcl_uc(cl_sim* prm_0) { return prm_0->uc; }

extern "C" __declspec(dllexport) void setmemaccess_r2k(cl_r2k* prm_1, int (*prm_2)(int, int, int)) { prm_1->setr2kmemaccess(prm_2); }
extern "C" __declspec(dllexport) void setmemaccess_r3ka(cl_r3ka* prm_1, int (*prm_2)(int, int, int)) { prm_1->setr2kmemaccess(prm_2); }
extern "C" __declspec(dllexport) void setmemaccess_z80(cl_z80 * prm_1, int (*prm_2)(int, int, int)) { prm_1->setz80memaccess(prm_2); }
extern "C" __declspec(dllexport) void setmemaccess_ez80(cl_ez80 * prm_1, int (*prm_2)(int, int, int)) { prm_1->setz80memaccess(prm_2); }

extern "C" __declspec(dllexport) int execcpu_r2k(cl_r2k * prm_1) { return prm_1->exec_inst(); }
extern "C" __declspec(dllexport) int execcpu_r3ka(cl_r3ka * prm_1) { return prm_1->exec_inst(); }
extern "C" __declspec(dllexport) int execcpu_z80(cl_z80 * prm_1) { return prm_1->exec_inst(); }
extern "C" __declspec(dllexport) int execcpu_ez80(cl_ez80 * prm_1) { return prm_1->exec_inst(); }

extern "C" __declspec(dllexport) int execcpu_wc_r2k(cl_r2k * prm_1) { int oldclock = prm_1->inst_ticks; prm_1->exec_inst(); return (prm_1->inst_ticks - oldclock); }
extern "C" __declspec(dllexport) int execcpu_wc_r3ka(cl_r3ka * prm_1) { int oldclock = prm_1->inst_ticks; prm_1->exec_inst(); return (prm_1->inst_ticks - oldclock); }
extern "C" __declspec(dllexport) int execcpu_wc_z80(cl_z80 * prm_1) { int oldclock = prm_1->inst_ticks; prm_1->exec_inst(); return (prm_1->inst_ticks - oldclock); }
extern "C" __declspec(dllexport) int execcpu_wc_ez80(cl_ez80 * prm_1) { int oldclock = prm_1->inst_ticks; prm_1->exec_inst(); return (prm_1->inst_ticks - oldclock); }

extern "C" __declspec(dllexport) int intcpu(cl_uc * prm_0) { return prm_0->do_interrupt(); }

extern "C" __declspec(dllexport) void intr2kcpu(cl_r2k * prm_0, u8_t prm_1) { prm_0->rxkextint(prm_1); }
extern "C" __declspec(dllexport) void intr3kacpu(cl_r3ka * prm_0, u8_t prm_1) { prm_0->rxkextint(prm_1); }

extern "C" __declspec(dllexport) void* getz80pc(cl_z80 * prm_0) { return &prm_0->PC; }
extern "C" __declspec(dllexport) void* getr2kpc(cl_r2k * prm_0) { return &prm_0->PC; }
extern "C" __declspec(dllexport) void* getr3kapc(cl_r3ka * prm_0) { return &prm_0->PC; }
extern "C" __declspec(dllexport) void* getez80pc(cl_ez80 * prm_0) { return &prm_0->PC; }

extern "C" __declspec(dllexport) void* getr2k_ioi_regs(cl_r2k * prm_0) { return &prm_0->r2k_ioi_regs; }
extern "C" __declspec(dllexport) void* getr3ka_ioi_regs(cl_r3ka * prm_0) { return &prm_0->r2k_ioi_regs; }

extern "C" __declspec(dllexport) void* getez80_inst_ticks(cl_ez80 * prm_0) { return &prm_0->inst_ticks; }
extern "C" __declspec(dllexport) void* getr2k_inst_ticks(cl_r2k * prm_0) { return &prm_0->inst_ticks; }
extern "C" __declspec(dllexport) void* getr3ka_inst_ticks(cl_r3ka * prm_0) { return &prm_0->inst_ticks; }
extern "C" __declspec(dllexport) void* getz80_inst_ticks(cl_z80 * prm_0) { return &prm_0->inst_ticks; }

extern "C" __declspec(dllexport) void r2kcpureset(cl_r2k * prm_0) { prm_0->cpureset(); }
extern "C" __declspec(dllexport) void r3kacpureset(cl_r3ka * prm_0) { prm_0->cpureset(); }

extern "C" __declspec(dllexport) void* getr2kmmureg(cl_r2k * prm_0) { return &prm_0->mmu; }
extern "C" __declspec(dllexport) void* getr3kammureg(cl_r3ka * prm_0) { return &prm_0->mmu; }

extern "C" __declspec(dllexport) void* getr2kreg(cl_r2k * prm_0) { return &prm_0->regs; }
extern "C" __declspec(dllexport) void* getr3kareg(cl_r3ka * prm_0) { return &prm_0->regs; }
extern "C" __declspec(dllexport) void* getz80reg(cl_z80 * prm_0) { return &prm_0->regs; }
extern "C" __declspec(dllexport) void* getez80reg(cl_ez80 * prm_0) { return &prm_0->regs; }

extern "C" __declspec(dllexport) void putchario_r2k(cl_r2k * prm_0, int prm_1,int prm_2) { prm_0->putchario(prm_1,prm_2); }
extern "C" __declspec(dllexport) void putchario_r3ka(cl_r3ka * prm_0, int prm_1, int prm_2) { prm_0->putchario(prm_1, prm_2); }

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

