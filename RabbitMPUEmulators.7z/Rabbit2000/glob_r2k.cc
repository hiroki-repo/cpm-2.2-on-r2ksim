#define R2K 1

#include "glob.cc"
